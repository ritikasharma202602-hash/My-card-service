const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const nodemailer = require("nodemailer");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "enquiries.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  name: "mcs.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 2 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));

const submitLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 6, standardHeaders: true, legacyHeaders: false });

function readEnquiries() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); } catch { return []; }
}
function writeEnquiries(items) { fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2)); }
function clean(v, max=180) { return String(v || "").trim().replace(/[<>]/g, "").slice(0, max); }
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: "Please sign in again." });
}
function mailer() {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || "true") === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

app.post("/api/enquiries", submitLimiter, async (req, res) => {
  // Honeypot field: ordinary visitors never see this input.
  if (req.body.website) return res.json({ ok: true });
  const name = clean(req.body.name, 90);
  const phone = clean(req.body.phone, 30);
  const email = clean(req.body.email, 120);
  const service = clean(req.body.service, 80);
  const message = clean(req.body.message, 1000);
  if (!name || !phone || !service) return res.status(400).json({ error: "Please fill in name, phone and service." });
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Please enter a valid email address." });

  const item = { id: Date.now().toString(36) + Math.random().toString(36).slice(2,7), name, phone, email, service, message, createdAt: new Date().toISOString(), status: "New" };
  const items = readEnquiries();
  items.unshift(item);
  writeEnquiries(items);

  const to = process.env.NOTIFY_EMAIL || "kaminisharma80818081@gmail.com";
  const transport = mailer();
  if (transport) {
    try {
      await transport.sendMail({
        from: process.env.SMTP_USER,
        to,
        subject: `New website enquiry: ${name}`,
        text: `A new enquiry was submitted.\\n\\nName: ${name}\\nPhone: ${phone}\\nEmail: ${email || "Not provided"}\\nService: ${service}\\nMessage: ${message || "None"}\\nReceived: ${item.createdAt}\\n\\nView it in your admin dashboard.`
      });
    } catch (err) {
      console.error("Email notification failed:", err.message);
    }
  } else {
    console.warn("SMTP is not configured; enquiry saved but email was not sent.");
  }
  res.json({ ok: true, message: "Thank you. Your enquiry has been received." });
});

app.post("/api/admin/login", loginLimiter, async (req, res) => {
  const username = clean(req.body.username, 80);
  const password = String(req.body.password || "");
  const expectedUser = process.env.ADMIN_USERNAME || "admin";
  const expectedPass = process.env.ADMIN_PASSWORD;
  if (!expectedPass) return res.status(503).json({ error: "Admin password is not configured. Set ADMIN_PASSWORD in environment variables." });
  const valid = username === expectedUser && password.length > 0 && await bcrypt.compare(password, await bcrypt.hash(expectedPass, 10));
  if (!valid) return res.status(401).json({ error: "Incorrect username or password." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start admin session." });
    req.session.isAdmin = true;
    res.json({ ok: true });
  });
});
app.post("/api/admin/logout", requireAdmin, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/admin/me", (req, res) => res.json({ authenticated: !!(req.session && req.session.isAdmin) }));
app.get("/api/admin/enquiries", requireAdmin, (req, res) => res.json(readEnquiries()));
app.patch("/api/admin/enquiries/:id", requireAdmin, (req, res) => {
  const items = readEnquiries();
  const item = items.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Enquiry not found." });
  const status = clean(req.body.status, 20);
  if (!["New", "In progress", "Resolved"].includes(status)) return res.status(400).json({ error: "Invalid status." });
  item.status = status;
  writeEnquiries(items);
  res.json({ ok: true });
});
app.delete("/api/admin/enquiries/:id", requireAdmin, (req, res) => {
  const items = readEnquiries();
  const next = items.filter(x => x.id !== req.params.id);
  if (next.length === items.length) return res.status(404).json({ error: "Enquiry not found." });
  writeEnquiries(next);
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`My Card Services running on port ${PORT}`));
